package com.example.prak_modul2

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewParent
import androidx.recyclerview.widget.RecyclerView

class myAdapter(private val data : ArrayList<img_temp>): RecyclerView.Adapter<viewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, ViewType:Int): viewHolder {
        val inflater = LayoutInflater.from(parent.context) //konteks bentuk view holder
        return viewHolder(inflater,parent)

    }
    //mengembalikan jumlah data recycler view
    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        holder.bind(data[position])
    }
}