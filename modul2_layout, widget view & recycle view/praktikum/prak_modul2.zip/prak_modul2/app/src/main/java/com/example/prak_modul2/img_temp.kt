package com.example.prak_modul2

class img_temp (val imgView:Int, val txtTitle:String, val txtSub:String)