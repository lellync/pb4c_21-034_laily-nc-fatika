package com.example.prak_modul2

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.zip.Inflater

class viewHolder(inflater: LayoutInflater, parent: ViewGroup):
    RecyclerView.ViewHolder(inflater.inflate(R.layout.recycler_view_temp, parent,false)) {

    private var imgView: ImageView? = null
    private var txtTitle1: TextView?= null
    private var txtSubTitle: TextView?= null

    //inisiasi variable
    init {
        imgView = itemView.findViewById(R.id.img_view)
        txtTitle1 = itemView.findViewById(R.id.txt_title)
        txtSubTitle = itemView.findViewById(R.id.text_isi)
    }
    //bind data image
    fun bind (data: img_temp){
        imgView?.setImageResource(data.imgView)
        txtTitle1?.text = data.txtTitle
        txtSubTitle?.text = data.txtSub
    }
}