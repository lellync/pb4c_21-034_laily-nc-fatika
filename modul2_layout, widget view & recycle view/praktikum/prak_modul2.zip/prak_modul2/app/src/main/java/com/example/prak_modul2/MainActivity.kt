package com.example.prak_modul2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var rec_view : RecyclerView
    lateinit var adapter: myAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        init()

        rec_view.layoutManager = LinearLayoutManager(this)
        rec_view.adapter = adapter
    }
    private fun init() {
        rec_view = findViewById(R.id.rec_view)

        var data = ArrayList<img_temp>()
        data.add(img_temp(R.drawable.p1, "PAHLAWAN 1", "Ini merupakan pahlawan pada list 1"))
        data.add(img_temp(R.drawable.p2, "PAHLAWAN 2", "Ini merupakan pahlawan pada list 2"))
        data.add(img_temp(R.drawable.p3, "PAHLAWAN 3", "Ini merupakan pahlawan pada list 3"))
        data.add(img_temp(R.drawable.p4, "PAHLAWAN 4", "Ini merupakan pahlawan pada list 4"))
        data.add(img_temp(R.drawable.p5, "PAHLAWAN 5", "Ini merupakan pahlawan pada list 5"))
        data.add(img_temp(R.drawable.p6, "PAHLAWAN 6", "Ini merupakan pahlawan pada list 6"))
        data.add(img_temp(R.drawable.p7, "PAHLAWAN 7", "Ini merupakan pahlawan pada list 7"))
        data.add(img_temp(R.drawable.p1, "PAHLAWAN 8", "Ini merupakan pahlawan pada list 8"))
        data.add(img_temp(R.drawable.p2, "PAHLAWAN 9", "Ini merupakan pahlawan pada list 9"))
        data.add(img_temp(R.drawable.p3, "PAHLAWAN 10", "Ini merupakan pahlawan pada list 10"))
        data.add(img_temp(R.drawable.p4, "PAHLAWAN 11", "Ini merupakan pahlawan pada list 11"))
        data.add(img_temp(R.drawable.p5, "PAHLAWAN 12", "Ini merupakan pahlawan pada list 12"))
        data.add(img_temp(R.drawable.p6, "PAHLAWAN 13", "Ini merupakan pahlawan pada list 13"))
        data.add(img_temp(R.drawable.p7, "PAHLAWAN 14", "Ini merupakan pahlawan pada list 14"))
        data.add(img_temp(R.drawable.p1, "PAHLAWAN 15", "Ini merupakan pahlawan pada list 15"))
        data.add(img_temp(R.drawable.p2, "PAHLAWAN 16", "Ini merupakan pahlawan pada list 16"))
        data.add(img_temp(R.drawable.p3, "PAHLAWAN 17", "Ini merupakan pahlawan pada list 17"))
        data.add(img_temp(R.drawable.p4, "PAHLAWAN 18", "Ini merupakan pahlawan pada list 18"))
        data.add(img_temp(R.drawable.p5, "PAHLAWAN 19", "Ini merupakan pahlawan pada list 19"))
        data.add(img_temp(R.drawable.p6, "PAHLAWAN 20", "Ini merupakan pahlawan pada list 20"))
        data.add(img_temp(R.drawable.p7, "PAHLAWAN 21", "Ini merupakan pahlawan pada list 21"))

        // set adapter 
        //
        // inisialissi variable null
        adapter=myAdapter(data)
    }
}